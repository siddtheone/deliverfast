import { useQuery } from "react-query";

export function useLogin() {}
